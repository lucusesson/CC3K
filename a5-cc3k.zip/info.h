class Character;

struct Info {
	Character * ch;
	int x, y;
	int displacedX, displacedY;
};
